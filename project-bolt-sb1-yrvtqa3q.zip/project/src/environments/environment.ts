export const environment = {
  production: false,
  supabaseUrl: 'https://gnjctnmwsfsipbpsbdjh.supabase.co',
  supabaseKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImduamN0bm13c2ZzaXBicHNiZGpoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njg0NzQ3NzQsImV4cCI6MjA4NDA1MDc3NH0.7uTV4cIt5lYBZXyYLjvwPNviG7UrQHW-3nDGAiLCMR0'
};
